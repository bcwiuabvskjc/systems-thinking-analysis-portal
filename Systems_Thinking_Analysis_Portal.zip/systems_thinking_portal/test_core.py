import pandas as pd
from analysis_core import validate_dataframe, coerce_numeric, detect_cross_impact, cross_impact_metrics, build_excel
from openpyxl import load_workbook
import io

def test_matrix_and_export():
    a = pd.read_csv('sample_cross_impact.csv')
    m, _ = detect_cross_impact(a)
    assert m is not None
    met, _ = cross_impact_metrics(m)
    assert met.loc[met.Factor == 'A', 'Influence (row sum)'].iloc[0] == 3
    assert met.loc[met.Factor == 'B', 'Dependence (column sum)'].iloc[0] == 6
    b = pd.read_csv('sample_relationships.csv')
    m2, _ = detect_cross_impact(b, 'source', 'target', 'impact')
    assert m2 is not None and m2.loc['B', 'C'] == 2
    params = pd.DataFrame([{'Parameter':'file','Value':'A','Status':'input'}])
    xlsx = build_excel(a, 'A.csv', coerce_numeric(a), validate_dataframe(a), params, m, met, pd.DataFrame(), ['test'])
    wb = load_workbook(io.BytesIO(xlsx), read_only=True)
    assert 'Original Data' in wb.sheetnames and 'Cross-Impact Matrix' in wb.sheetnames

def test_validation_and_independence():
    a = pd.DataFrame({'Factor':['A','B'], 'value':[1,2]})
    b = pd.DataFrame({'Factor':['X','Y'], 'value':[10,20]})
    assert coerce_numeric(a)['value'].sum() == 3
    assert coerce_numeric(b)['value'].sum() == 30
    bad = pd.DataFrame({'x':[1, None]})
    assert (validate_dataframe(bad)['Check'] == 'Missing values').any()

if __name__ == '__main__':
    test_matrix_and_export(); test_validation_and_independence()
    print('All core tests passed.')
